%tdemo_edge1.m or ws3_3b.m find edge image of a real image, 
%put test.jpg in c:\images\  ,tested ok on octave
clear
%iicolor=imread('c:\\images\\test14915.jpg');
%ii=rgb2gray(iicolor); %convert into gray level image
ii=imread('lena_gray.jpg');
prew_x=[-1 0 1; -1 0 1; -1 0 1]
ex=conv2(ii, prew_x);
prew_y=[1 1 1; 0 0 0; -1 -1 -1]
ey=conv2(ii, prew_y);
%If edge image is required: 
etemp=sqrt(ex.*ex+ey.*ey);
e=etemp;
threshold=mean(mean(etemp))% set threshold, or hard set to 128
%threshold=128% set threshold, or hard set to 128

e(e<=threshold)=0; %< threshold, set to 0
e(e>threshold)=255;%> threshold, set to 255
figure(1),clf
subplot(2,2,1)
colormap(gray(256))
image(ii)
ylabel('real image')
 subplot(2,2,3)
colormap(gray(256))
image(e)
ylabel('edge image')
