% demo_harris1, Harris detector, %modidied from
%http://www.mathworks.com/matlabcentral/fileexchange/9272-harris-corner-detector
% A. Ganoun
%load Imag
%frame=imread('c:\\images\\test.jpg');
%frame=imread('test.jpg'); %if your image is at the current directory
frame=imread('office41_gray.jpg'); %if your image is at the current directory


I =double(frame);
%****************************
imshow(frame);
'hit any key to find corners'
%pause
[row_max,column_max]=size(frame)
%pause

full_frame_test=1
if full_frame_test==1
    
    ymin = 1+10 %the value "10" is to leave some room for edges
    ymax = column_max-10
    
    xmin = 1+10
    xmax = row_max-10
else
    %pick an area of test.jpg to look clearly 
    %try 460 413, ou try other values, see results of full_frame_test
    dd=4
    xx_min=102-dd
    xx_max=102+dd
    
    yy_min=96-dd
    yy_max=96+dd
    
    ymin = yy_min%1+10
    ymax = yy_max% column_max-10
    
    xmin = xx_min%1+10
    xmax = xx_max%row_max-10
end
%***********************************
Aj=6;
cmin=xmin-Aj; cmax=xmax+Aj; rmin=ymin-Aj; rmax=ymax+Aj;
%min_N=12;max_N=16; %orginal
min_N=112;max_N=116; %want more
%%%%%%%%%%%%%%Intrest Points %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%sigma=2; Thrshold=20; r=6; disp=1;
sigma=2; Thrshold=20; r=6; disp=1;

dx = [-1 0 1; -1 0 1; -1 0 1]; % The Mask
dy = dx';
%%%%%%
Ix = conv2(I(cmin:cmax,rmin:rmax), dx, 'same');
Iy = conv2(I(cmin:cmax,rmin:rmax), dy, 'same');
g = fspecial('gaussian',max(1,fix(6*sigma)), sigma); %%%%%% Gaussien Filter

%%%%%
Ix2 = conv2(Ix.^2, g, 'same');
Iy2 = conv2(Iy.^2, g, 'same');
Ixy = conv2(Ix.*Iy, g,'same');
%%%%%%%%%%%%%%
k = 0.04;
R11 = (Ix2.*Iy2 - Ixy.^2) - k*(Ix2 + Iy2).^2;
R11=(1000/max(max(R11)))*R11;
R=R11;
ma=max(max(R));
sze = 2*r+1;
MX = ordfilt2(R,sze^2,ones(sze));
R11 = (R==MX)&(R>Thrshold);
count=sum(sum(R11(5:size(R11,1)-5,5:size(R11,2)-5)));

figure(2)
subplot(2,2,1)
surf(Ix2)
xlabel('x-axis'),ylabel('y-axis'),zlabel('Ix^2(x,y)')

subplot(2,2,2)
surf(Iy2)
xlabel('x-axis'),ylabel('y-axis'),zlabel('Iy^2(x,y)')

subplot(2,2,3)
surf(Ixy)
xlabel('x-axis'),ylabel('y-axis'),zlabel('Ixy(x,y)')

'hit any key to continue'
%pause

loop=0;
while (((count<min_N)|(count>max_N))&(loop<30))
    if count>max_N
        Thrshold=Thrshold*1.5;
    elseif count < min_N
        Thrshold=Thrshold*0.5;
    end
    
    R11 = (R==MX)&(R>Thrshold);
    count=sum(sum(R11(5:size(R11,1)-5,5:size(R11,2)-5)));
    loop=loop+1;
end


R=R*0;
R(5:size(R11,1)-5,5:size(R11,2)-5)=R11(5:size(R11,1)-5,5:size(R11,2)-5);
[r1,c1] = find(R);
PIP=[r1+cmin,c1+rmin]%% IP


%%%%%%%%%%%%%%%%%%%% Display

Size_PI=size(PIP,1);
for r=1: Size_PI
    I(PIP(r,1)-2:PIP(r,1)+2,PIP(r,2)-2)=255;
    I(PIP(r,1)-2:PIP(r,1)+2,PIP(r,2)+2)=255;
    I(PIP(r,1)-2,PIP(r,2)-2:PIP(r,2)+2)=255;
    I(PIP(r,1)+2,PIP(r,2)-2:PIP(r,2)+2)=255;
    
end
figure(1)
clf

imshow(uint8(I))