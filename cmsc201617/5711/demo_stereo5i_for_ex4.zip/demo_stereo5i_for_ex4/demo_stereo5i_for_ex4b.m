%run thuis software enter 'n' as command
function [x1,x2,P1,P2,kint1,kint2]=gen_points(random_tag)
%clear, xmax=320 ,ymax=240  , xmin=-320,ymin=-240
clear
xmin_short=-4,xmax_short=4 , ymin_short=-4, ymax_short=4  
xmin_long=-240, ymin_long=-240 , xmax_long=240, ymax_long=240 
window_x=300,window_y=300
    
ppm=5*10^-6;%ppm=pixel_per_meter
f=5*10^-3/ppm; %f1=focal length of cam1, f is 1000
kint1=[f 0 0; 0 f 0; 0 0 1]; %assume ox, oy are 0
kint2=[f 0 0; 0 f 0; 0 0 1];%assume ox, oy are 0

%T_cam2_x=-0.2, T_cam2_y=0.05, T_cam2_z=0.1;
%T_cam2_x_meter=-0.2, T_cam2_y_meter=0, T_cam2_z_meter=0
T_cam2_x_meter=-0.2, T_cam2_y_meter=-.015, T_cam2_z_meter=-0.25;
T_cam2_x=T_cam2_x_meter/ppm;
T_cam2_y=T_cam2_y_meter/ppm;
T_cam2_z=T_cam2_z_meter/ppm;

an_xx=0,an_yy=2,an_zz=0;

random_tag=0
if random_tag==1
    N=8 %N features
    rand_PP=(rand(3,N)-0.5);
    init_Z_meter=1 % in meters
    P1_meter=repmat([0,0,init_Z_meter]',1,N)+0.3*rand_PP %init_Z is teh center of the points
else
    %forced example for points in p1
    P1_meter =[
    0.0086   -0.0711    0.0744   -0.0813    0.0977   -0.1265    0.1386    0.0952
   -0.1003    0.0462   -0.0148    0.1240    0.0115   -0.0172   -0.1486    0.1106
    1.0306    1.0568    0.8751    0.8957    1.1488    0.8820    1.0825    0.8753]
end
P1=P1_meter/ppm %p1 is in pixels
P1=P1 
[foo,N]=size(P1)
'see input data P1'
%pause
%cam1 left(ref/world), cam2 right camera
%Tc=[0/ppm,-0.1/ppm,0/ppm]'; %motion of cam2 in cam1 coord.
command=0;

%while(command ~= 'q' ||command == '' )
while(1) %break when 'q' is entered
    'a point is at [0,0,1] meter in cam2 cooodinates, ppm=5um, f=5mm'
    command = input('Move cam2:translate(a<, s>, w^, zv),r(y-axis: +ve),c(y-axis: -ve),,n(no change)q=quit : ', 's');
% command
% pause
    switch command
        case {'a'} ,T_cam2_x=T_cam2_x+0.05
        case {'s'} ,T_cam2_x=T_cam2_x-0.05
        case {'w'} ,T_cam2_y=T_cam2_y+0.05
        case {'z'} ,T_cam2_y=T_cam2_y-0.05
        case {'r'} ,an_yy=an_yy+1
        case {'c'} ,an_yy=an_yy-1
        case {'n'} ,'no change'
        case {'q'} ,'break',break
   %     case (''),'return ================no change' , pause    
            
        otherwise  ,disp('Unknown command'),pause,
    end
    T_cam2_x=T_cam2_x_meter/ppm;
    T_cam2_y=T_cam2_y_meter/ppm;
    T_cam2_z=T_cam2_z_meter/ppm;
    
    T_cam2=[T_cam2_x,T_cam2_y,T_cam2_z]' %motion of cam2 in cam1 coord.
   an_xx=an_xx
    an_yy=an_yy
    an_zz=an_zz
   
  
    R_cam2=rot(an_xx*pi/180,an_yy*pi/180,an_zz*pi/180);%angles are rotation angles of a camera in x,y,z axes)
    %R_cam2 brings a vector in cam1 coordinates to cam2 coordinates (by defn)
    R=R_cam2; %R in chpater 8 and R_cam2 (Rc) in chapter 2 are the same
    T=-R*T_cam2; %realte T and T-cam2
    P2=R*P1 + repmat(T,1,N); %this forumla is used in chapter 8-stereo
    P1
    P2
    x1=kint1*P1
    x2=kint2*P2
  
    
    '%image coordinates of cam1'
    u1=(x1(1,:)./x1(3,:))'%image coordinates of cam1
    v1=(x1(2,:)./x1(3,:))'
    
    '%image coordinates of cam2'
    u2=(x2(1,:)./x2(3,:))' %image coordinates of cam2
    v2=(x2(2,:)./x2(3,:))'
    
    
    figure(1)
    clf
    
    subplot(2,2,1)% of figure(1)
    set(gca,'XDir','reverse')%%right hand display convention,
    hold on
    plot(u1,v1,'ro');
    plot(-window_x,-window_x,'b.'),plot(window_y,window_y,'r+') %define the window frame
    title('left image, cam1')
    
    subplot(2,2,2)% of figure(1)
    set(gca,'XDir','reverse')%%right hand display convention,
    hold on
    plot(u2,v2,'ro');
    title('right image, cam2')
    plot(-window_x,-window_x,'b.'),plot(window_y,window_y,'r+') %define the window frame
    
    subplot(2,2,3)% of figure(1)
    hold on
    plot3(0,0,0,'bo')
    plot3(P1(1,:),P1(2,:),P1(3,:),'r+')
   view(3)
    
    xlabel('x-axis'), ylabel('y-axis'),zlabel('z-axis')
    title('       feature points 3D')
 
    %%%%%%%%%%% normalized u,v for findning F
    %([u1;v1;f*ones(1,N)] is the image point in homgenous coodintes
    %normalize homgenous image points, each point has 3 compments
     norm_mat1 = get_normalization_matrix([u1';v1';f*ones(1,N)] )
     norm_mat2 = get_normalization_matrix([u1';v1';f*ones(1,N)])
    %norm_mat1 = get_normalization_matrix(x1)
    %norm_mat2 = get_normalization_matrix(x2)
    
    normalize_tag=1
    if (normalize_tag==1)
        x1n = norm_mat1 * x1
        x2n = norm_mat2 * x2
    else
        x1n =  x1
        x2n =  x2
    end
       
    u1n=(x1n(1,:)./x1n(3,:))' %for calulation of F only, ploting use u1,v1
    v1n=(x1n(2,:)./x1n(3,:))'
    
    
    u2n=(x2n(1,:)./x2n(3,:))'
    v2n=(x2n(2,:)./x2n(3,:))'
 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% display normalised features
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(2)
    clf
    
    subplot(2,2,1)% of figure(2)
    set(gca,'XDir','reverse')%%right hand display convention,
    hold on,
    plot(xmin_short,ymin_short),plot(xmax_short,ymax_short)
    plot(u1n,v1n,'+')
    title('left image=reference--cam1 (u1n,v1n, normalised)')
    
    subplot(2,2,2)% of figure(2)
    set(gca,'XDir','reverse')%%right hand display convention,
    hold on,
     plot(xmin_short,ymin_short),plot(xmax_short,ymax_short)
    plot(u2n,v2n,'+')
    title('right image -- cam2 (u2n,v2n, normalised)')
    %  set(gca,'XDir','reverse'); % use right hand display convention
    
%     %%%% fundmental matrix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %normalized u,v s
    
    A=[u2n.*u1n, u2n.*v1n, u2n, v2n.*u1n, v2n.*v1n, v2n, u1n, v1n, ones(N,1)]
    [u_A,s_A,v_A]= svd(A)
    F=(reshape(v_A(:,9),3,3))'
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% find epipoles
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %//epipoles e1,e2 %// test program
    [uu1,ss1,vv1]= svd(F)
    FT=F'
    [uu2,ss2,vv2]= svd(FT)
    e1=vv1(:,3) %// epipole on the left image ---------------
    e1_u=e1(1)/e1(3)
    e1_v=e1(2)/e1(3)
    e2=vv2(:,3) %// epipole on the right image ---------------
    e2_u=e2(1)/e2(3)
    e2_v=e2(2)/e2(3)
    
    'left epipole'
    [e1_u,e1_v]
    'right epipole'
    [e2_u,e2_v]
'for exercise 4 in notes, no change input entered command-n'
    %pause
    
    '%checking:defn: e2�*F*e1=0 or e1�*FT*e2=0,should see 2 zeros following'
    %//because e1, e2 are on Image 1, image 2 resp.
    (e2')*F*e1
    (e1')*FT*e2
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%plot each epipole lines %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(3)
    clf
    hold on
    for n=1:N %plot each epipole lines
        
        %find ep lines in cam2 of image points [u1n,vn1] of the left image
        ep_line(:,n)=F*[u1n(n),v1n(n),1]' %line formula is : ax+by+c=0
        a(n)=ep_line(1,n),b(n)=ep_line(2,n),c(n)=ep_line(3,n)%eplines @cam2
        
        %plot line 1 in the left  iamge cam1
    %%%%%%%title('normlaised cam1')%%%%%%%%%%%%%
        subplot(2,2,1) % of figure(3)%left image , plot point
        set(gca,'XDir','reverse')%%right hand display convention,
        hold on,
        plot(xmin_short,ymin_short),plot(xmax_short,ymax_short)
    
        plot(u1n(n),v1n(n),'r+')
        num_txt=sprintf('%d',n),text(u1n(n),v1n(n),num_txt)
        title('normlaised cam1')
        
    %%%%title('normlaised cam2')%%%%%%%%%%%%
        subplot(2,2,2)% of figure(3) %right image, plot point and line
        set(gca,'XDir','reverse')%%right hand display convention,
        hold on,
        plot(xmin_short,ymin_short),plot(xmax_short,ymax_short)
        plot(u2n(n),v2n(n),'r+')
        num_txt=sprintf('%d',n),text(u2n(n),v2n(n),num_txt)
        title('normlaised cam2')
        
    %%%%title('normlaised cam1 and ep line') %%%%%%%%%%%%%%%%%%%
        subplot(2,2,3)% of figure(3) %right image, plot point and ep line
        set(gca,'XDir','reverse')%%right hand display convention,
        hold on,
        plot(xmin_short,ymin_short),plot(xmax_short,ymax_short)
        plot(u2n(n),v2n(n),'r+')
        num_txt=sprintf('%d',n),text(u2n(n),v2n(n),num_txt)
        title('normlaised cam1 and ep line -- [short]')
    %%%% plot ep line in cam2 (short)     
        %if the line frmula is ax+by+c=0
        %x=(-b*y-c)/a, y=(-a*x-c)/b
        %at x=-4,
        xx1= xmin_short %plot short ep line, set xmin to be the same scale as left
        yy1=(-a(n)*xx1-c(n))/b(n)
        xx2=xmax_short %%plot short ep line, set xmax to be the same scale as left
        yy2=(-a(n)*xx2-c(n))/b(n)
        plot([xx1 xx2],[yy1,yy2],'-')
        title('cam2 and ep lines --[short]')
        
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        subplot(2,2,4)% of figure(3) %plot right epipole,same as above but large plot area
       set(gca,'XDir','reverse')%%right hand display convention,       
       hold on
        plot(u2n(n),v2n(n),'r+') %plot cam2 feature
        xx1= xmin_short% xmin_long
        yy1=(-a(n)*xx1-c(n))/b(n)
        xx2= xmax_short
        yy2=(-a(n)*xx2-c(n))/b(n)
        plot([xx1 xx2],[yy1,yy2],'-')
        plot([xx1 xx2],[yy1,yy2],'-')
        title ('cam2 features ,ep liens ,[short]')
        %title ('cam2 features ,ep liens ,[long]')
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        'check:[u2n(1),v2n(1),1]*line1(:,n),the following value should be 0'
        [u2n(n),v2n(n),1]*ep_line(:,n)
        
    end
    %for exercise
    for n=1:N %plot each epipole lines
        n
        ep_line(:,n)
        
    end
    ep_line(:,5)
    ep_line(:,7)
    
    A1=a(5), B1=b(5), C1=-c(5) %line 5
    A2=a(7), B2=b(7), C2=-c(7) %line 7
    'for exercise 4: line5,7 are  as above'
    
    %http://www.aishack.in/2010/04/solving-for-intersection-of-lines-efficiently/
    det=A1*B2-A2*B1
    ep2_x = (B2*C1-B1*C2)/det
    ep2_y = (A1*C2-A2*C1)/det
    'epiople2 by two lines using the meeting pt of two ep lines is '
    %pause
    e2_u=e2(1)/e2(3)
    e2_v=e2(2)/e2(3)
    'epipole 2 by svd,should be same as above,ie ep2_x=ep2_u, ep2_y=ep2_v'
    pause
    
   
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function Rc =rot(an_x,an_y,an_z)
Rz=[cos(an_z)       sin(an_z)   0
    -sin(an_z)  cos(an_z)   0
    0          0           1];

Ry=[cos(an_y)       0           -sin(an_y)
    0               1           0
    sin(an_y)       0           cos(an_y)];

Rx=[1               0           0
    0               cos(an_x)   sin(an_x)
    0               -sin(an_x)  cos(an_x)];
Rc = Rx*Ry*Rz;

